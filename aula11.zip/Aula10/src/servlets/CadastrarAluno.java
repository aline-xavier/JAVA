package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Aluno;
import persistence.DAOAluno;


@WebServlet("/CadastrarAluno")
public class CadastrarAluno extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet pode ser executado por um server diretamente
		
	try{
		
		String matricula = request.getParameter("matricula");
		String nome = request.getParameter("nome");
		String curso = request.getParameter("curso");
		String telefone = request.getParameter("telefone");
		
		Aluno a = new Aluno();
		a.setMatricula(matricula);
		a.setNome(nome);
		a.setCurso(curso);
		a.setTelefone(telefone);
		
		DAOAluno dao = new DAOAluno();
		dao.cadastrar(a);
		
		request.setAttribute("msg", "Cadastro com sucesso");
			
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("msg", "Erro ao cadastrar");
	}
	
	request.getRequestDispatcher("form-aluno.jsp").forward(request, response);

}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("form-aluno.jsp").forward(request, response);
	}
}