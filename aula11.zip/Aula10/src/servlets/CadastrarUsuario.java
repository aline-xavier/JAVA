package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;
import persistence.DAOUsuario;


@WebServlet("/CadastrarUsuario")
public class CadastrarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	try{
		String nome= request.getParameter("nome");
		String endereco = request.getParameter("endereco");
		String email = request.getParameter("email");
		String receita = request.getParameter("receita");
		
		Usuario a = new Usuario();
		a.setEndereco(endereco);
		a.setNome(nome);
		a.setEmail(email);
		a.setReceita(receita);
		
		DAOUsuario dao = new DAOUsuario();
		dao.cadastrar(a);
		
		request.setAttribute("msg", "Cadastro com sucesso");
			
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("msg", "Erro ao cadastrar");
	}
	
	request.getRequestDispatcher("form-usuario.jsp").forward(request, response);

}
}