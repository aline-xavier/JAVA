package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Curso;
import persistence.DAOCurso;


@WebServlet("/CadastrarCurso")
public class CadastrarCurso extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	try{
		String nome= request.getParameter("nome");
		String preRequesito = request.getParameter("preRequesito");
		String cargaHora = request.getParameter("cargaHora");
		String valor = request.getParameter("valor");
		
		Curso a = new Curso();
		
		a.setNome(nome);
		a.setPreRequesito(preRequesito);
		a.setCargaHora(cargaHora);
		a.setValor  (valor);
		
		DAOCurso dao = new DAOCurso();
		dao.cadastrar(a);
		
		request.setAttribute("msg", "Cadastro com sucesso");
			
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("msg", "Erro ao cadastrar");
	}
	
	request.getRequestDispatcher("form-curso.jsp").forward(request, response);

}
}