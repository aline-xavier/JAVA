package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Produto;
import persistence.DAOProduto;


@WebServlet("/CadastrarProduto")
public class CadastrarProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	try{
		String nome_produto= request.getParameter("nome_produto");
		String quantidadeEstoque= request.getParameter("quantidadeEstoque");
		String preco = request.getParameter("preco");
		
		Produto a = new Produto();
		
		a.setNome_Produto(nome_produto);
		a.setQuantidadeEstoque(quantidadeEstoque);
		a.setPreco(preco);
		
		DAOProduto dao = new DAOProduto();
		dao.cadastrar(a);
		
		request.setAttribute("msg", "Cadastro com sucesso");
			
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("msg", "Erro ao cadastrar");
	}
	
	request.getRequestDispatcher("form-produto.jsp").forward(request, response);

}
}