package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import persistence.DAOProfessor;

/**
 * Servlet implementation class ListaDeAlunos
 */
@WebServlet("/ListaDeProfessores")
public class ListaDeProfessores extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			DAOProfessor dao = new DAOProfessor();
			request.setAttribute("lista",dao.getLista());
		}catch (Exception e){
			request.setAttribute("msg","Nenhum Professor Cadastrado");
		}
		request.getRequestDispatcher("lista-professor.jsp").forward(request,response);

	}


}
