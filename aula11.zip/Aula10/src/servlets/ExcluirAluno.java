package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import persistence.DAOAluno;

@WebServlet("/ExcluirAluno")
public class ExcluirAluno extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			
			Long id = Long.parseLong(request.getParameter("id"));
			DAOAluno dao = new DAOAluno();
			dao.excluir(id);
			
			request.setAttribute("msg", "Exclu�do com sucesso");
			
		}catch(Exception e){
			request.setAttribute("msg", "Erro ao excluir");
			
		}
		
		request.getRequestDispatcher("/ListaDeAlunos").forward(request, response);
	
	}

}
