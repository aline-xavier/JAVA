package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Professor;
import persistence.DAOProfessor;


@WebServlet("/CadastrarProfessor")
public class CadastrarProfessor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet pode ser executado por um server diretamente
		
	try{
		
		
		String nome = request.getParameter("nome");
		String curso = request.getParameter("curso");
		Double salario =Double.parseDouble(request.getParameter("salario"));
			
			Professor a = new Professor();
		a.setNome(nome);
		a.setCurso(curso);
		a.setSalario(salario);
		
		DAOProfessor dao = new DAOProfessor();
		dao.cadastrar(a);
		
		request.setAttribute("msg", "Cadastro com sucesso");
			
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("msg", "Erro ao cadastrar");
	}
	
	request.getRequestDispatcher("form-professor.jsp").forward(request, response);

}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("form-professor.jsp").forward(request, response);
	}
}