package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Professor;
import persistence.DAOProfessor;

@WebServlet("/AtualizarProfessor")
public class AtualizarProfessor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try{
			
			Long id = Long.parseLong(request.getParameter("id"));
			DAOProfessor dao = new DAOProfessor();
			Professor professor = dao.getBuscaId(id); 
			
			request.setAttribute("professor", professor);
			
			
		}catch(Exception e){
			request.setAttribute("msg", "Nenhum professor encontrado");	
		}
		request.getRequestDispatcher("atualiza-professor.jsp").forward(request, response);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try{
			
			Professor a = new Professor();
			a.setId(Long.parseLong(request.getParameter("id")));
			a.setNome(request.getParameter("nome"));
			a.setCurso(request.getParameter("curso"));
			a.setSalario(Double.parseDouble(request.getParameter("salario")));
		
			DAOProfessor dao = new DAOProfessor();
			dao.atualiza(a);
			
			request.setAttribute("msg", "Atualizado com sucesso");
			
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("msg", "Erro ao atualizar");
		}
		doGet(request,response);
		
	
		}
}