package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Aluno;
import persistence.DAOAluno;



@WebServlet("/AtualizarAluno")
public class AtualizarAluno extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			
			// recuperando ID da Url
			Long id = Long.parseLong(request.getParameter("id"));
			
			DAOAluno dao = new DAOAluno();
			Aluno aluno = dao.getBuscaId(id); // busca o Aluno no banco
			
			//envia o aluno para a pagina edita-aluno.jsp
			request.setAttribute("aluno", aluno);

		}catch(Exception e){
			request.setAttribute("msg", "Nenhum aluno encontrado");	
		}
		request.getRequestDispatcher("atualiza-aluno.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	try{
		Aluno a = new Aluno();
		a.setId(Long.parseLong(request.getParameter("id")));
		a.setMatricula(request.getParameter("matricula"));
		a.setNome(request.getParameter("nome"));
		a.setCurso(request.getParameter("curso"));
		a.setTelefone(request.getParameter("telefone"));
		
		DAOAluno dao = new DAOAluno();
		dao.atualiza(a);
		request.setAttribute("msg","Atualizado com sucesso!");
	
		
	}catch (Exception e){
		e.printStackTrace();
		request.setAttribute("msg","Erro ao atualizar");
	}
	doGet(request,response);
			
	
	}

}
