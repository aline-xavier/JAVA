
package model;


import java.sql.Connection;
import java.sql.DriverManager;


public class Conexao {
	final private static String user = "root";
	final private static String password= "";
	final private static String driver = "jdbc:mysql://localhost:3066/java";
	private static Connection conexao = null;
	private static String status = "N�o conectado";
	
	final static Connection getConectar(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conexao = DriverManager.getConnection(driver, user,password);
			status = "conectado";
			
			
		}catch (Exception e){
			e.printStackTrace();
			status = "Houve um erro ao conectar";
		}
		return conexao;	
	}
	
	public static String getStatus(){
		return status;
	}
	
	
	
}
