package model;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="curso")

public class Curso {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private Long id;
	private String nome;
	private String preRequesito;
	private String cargaHora;
	private String valor;
	
	public String getNome() {
		return nome;
	}
	
	

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPreRequesito() {
		return preRequesito;
	}

	public void setPreRequesito(String preRequesito) {
		this.preRequesito = preRequesito;
	}

	public String getCargaHora() {
		return cargaHora;
	}

	public void setCargaHora(String cargaHora) {
		this.cargaHora = cargaHora;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id){
		this.id = id;
	}
	

}
