package model;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="produto")

public class Produto {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private  Integer id;
	private	 String	nome_produto;
	private	 String	quantidadeEstoque;
	private	 String	preco;
	
	public String getNome_Produto() {
		return nome_produto;
	}

	public void setNome_Produto(String nome_Produto) {
		this.nome_produto = nome_Produto;
	}

	public String getQuantidadeEstoque() {
		return quantidadeEstoque;
	}

	public void setQuantidadeEstoque(String quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}

	public String getPreco() {
		return preco;
	}

	public void setPreco(String preco) {
		this.preco = preco;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id){
		this.id = id;
	}

	

}

