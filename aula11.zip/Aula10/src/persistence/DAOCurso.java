package persistence;


import model.Curso;

public class DAOCurso extends DAO {

	public void cadastrar(Curso curso){
	entityManager.getTransaction().begin();
	entityManager.persist(curso);
	entityManager.getTransaction().commit();
	entityManager.close();

}
}