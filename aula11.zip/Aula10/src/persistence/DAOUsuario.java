package persistence;


import model.Usuario;

public class DAOUsuario extends DAO {

	public void cadastrar(Usuario usuario){
	entityManager.getTransaction().begin();
	entityManager.persist(usuario);
	entityManager.getTransaction().commit();
	entityManager.close();

}
}