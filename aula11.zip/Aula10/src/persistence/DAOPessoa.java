package persistence;

import javax.persistence.Query;

import java.util.List;

import model.Pessoa;

public class DAOPessoa extends DAO{
	
	public void cadastrar(Pessoa pessoa){
		entityManager.getTransaction().begin();
		entityManager.persist(pessoa);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	public List<Pessoa> getLista(){
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("from Pessoa p");
		List<Pessoa> lista = query.getResultList();
		entityManager.close();
		return lista;
	}
}
