package persistence;

import java.util.List;

import javax.persistence.Query;

import model.Aluno;

public class DAOAluno extends DAO {

	public void cadastrar(Aluno aluno){
	entityManager.getTransaction().begin();
	entityManager.persist(aluno);
	entityManager.getTransaction().commit();
	entityManager.close();
	

}
	public List<Aluno> getLista(){
	
		Query query = entityManager.createQuery("from Aluno p");
		List<Aluno> lista = query.getResultList();
		return lista; // LISTA O ALUNO
	}
	
	public Aluno getBuscaId(Long id){
		Aluno aluno = entityManager.find(Aluno.class, id);
		return aluno; // ATUALIZA O ALUNO
	}
	public void atualiza(Aluno aluno ){
		entityManager.getTransaction().begin();
		entityManager.merge(aluno);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public void excluir(Long id){
		entityManager.getTransaction().begin();
		entityManager.remove(getBuscaId(id));
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}