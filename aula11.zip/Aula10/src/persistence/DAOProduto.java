package persistence;


import model.Produto;

public class DAOProduto extends DAO {

	public void cadastrar(Produto produto){
	entityManager.getTransaction().begin();
	entityManager.persist(produto);
	entityManager.getTransaction().commit();
	entityManager.close();

}
}