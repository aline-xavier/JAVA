package persistence;

import java.util.List;

import javax.persistence.Query;

import model.Professor;

public class DAOProfessor extends DAO {

	public void cadastrar(Professor professor) {
		entityManager.getTransaction().begin();
		entityManager.persist(professor);
		entityManager.getTransaction().commit();
		entityManager.close();

	}

	public List<Professor> getLista() {
		Query query = entityManager.createQuery("from Professor p");
		List<Professor> lista = query.getResultList();
		return lista;
	}

	public Professor getBuscaId(Long id) {
		Professor professor = entityManager.find(Professor.class, id);
		return professor;
	}

	public void atualiza(Professor professor) {
		entityManager.getTransaction().begin();
		entityManager.merge(professor);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public void excluir(Long id) {
		entityManager.getTransaction().begin();
		entityManager.remove(getBuscaId(id));
		entityManager.getTransaction().commit();
		entityManager.close();
	}

}
